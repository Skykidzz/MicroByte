var ranon = 0;
var ll = [];
var ifl = []
var vars = []
var oo = []
var usD = 0;

function runScr() {
	if (ranon == 0) {
		var oten = 0;
		for (var i = 0; i < newl.length; i++) {
			if (newl[i].substring(0, 5) == "loop(") {
				oten++;
				oo.push(1)
				 ll.push([i + 1, -1, -1, -1,oten]);
				for(var k = 5; k < newl[i].length; k++) {
					if(newl[i].substring(k, k + 1) == ")") {
						if(k == 5) {
						ll[ll.length - 1][2] = -1
						ll[ll.length - 1][3] = -1
						}
					k = newl[i].length
					}else{
				ll[ll.length - 1][2] = (newl[i].substring(5, k))
				ll[ll.length - 1][3] = 0										
					}
				}
			}
			if(newl[i].substring(0, 3) == "if(") {
				oten++;
				oo.push(2)
				ifl.push([i, -1, oten])
			}
			if(newl[i].substring(0, 1) == "}") {
				oten--;
				if(oo[oo.length - 1] == 1) {
					oo.pop()
					ll[ll.length - 1][1] = i;
				}
				if(oo[oo.length - 1] == 2) {
					oo.pop()
					ifl[ifl.length - 1][1] = i;
				}
			}
		}
		passScr(0,newl.length)
		ranon++;
	}else{
		runLoop()
	}
}

function runLoop() {
	for(var i = 0; i < ll.length; i++) {
	if(ll[i][0] > -1) {
		if(ll[i][2] == -1 == false) {
			if(ll[i][3] < ll[i][2]) {
				passScr(ll[i][0], ll[i][1])
			}
			if(usD == 0) {
		ll[i][3] += 1;
			}else{
		ll[i][3] += 1 * delh;
			}
		}else{
		passScr(ll[i][0], ll[i][1])	
		}
	}
	}
}

function passScr(start,stop) {
	var ni = [0,0];
	ni[0] = ifl[ni[1]][0]
	//print(ni[0], newl)
	for (var i = start; i < stop; i++) {
		if(ni[0] == i) {
			if(deIf(newl[i]) == false) {
				i = ifl[ni[1]][1] + 1
			}
			if(ni[1] < ifl.length - 1) {
			ni[1]++;
			ni[0] = ifl[ni[1]][0]
			}
		}
		if(newl[i].substring(0,2) == "//" == false) {
	if (newl[i].substring(0, 5) == "rect(") {
				var par = []
				var k = 0;
				var d =5;
				var lo = 0;
				for(var j = 5; j < newl[i].length; j++) {
					lo = 0;
					if(newl[i].substring(j,j + 1) == "," == false && newl[i].substring(j,j + 1) == ")" == false) {
					if(vars.length > 0) {
								for(var g = 0; g < vars.length; g++) {
									if(newl[i].substring(d,j + 1) == vars[g][0]) {
						par[k] = "VAR:" + newl[i].substring(d,j + 1)
										lo = 1;
								}else{
										if(lo == 0) {
								par[k] = int(newl[i].substring(d,j + 1))
										}
								}
							}		
								}else{
								par[k] = int(newl[i].substring(d,j + 1))
								}		
				}else{
						k++;
						d = j + 1;
				}
				}
			//print(par)
		for(var j = 0; j < par.length; j++) {
			if(str(par[j]).substring(0,4) == "VAR:") {
				for(var k = 0; k < vars.length; k++) {
					if(par[j].substring(4,par[j].length) == vars[k][0]) {
						par[j] = vars[k][1]
						k = vars.length
					}
				}
			}
		}
		//print(par)
		rect(par[0],par[1],par[2],par[3])
			}
		if (newl[i].substring(0, 3) == "VAR") {
			var d = 0;
			var k = 3;
			var par = []
			for(var j = 3; j < newl[i].length; j++) {
									if(d == 0) {
				if(newl[i].substring(j,j + 1) == "=" == false) {
						par[0] = newl[i].substring(k,j + 1)
				}else{
					k = j + 1;
					d++
				}
				}else{
							if(newl[i].substring(j,j + 1) == ";" == false) {
						if(newl[i].substring(j,newl[i].length - 1 == "deltaTime()")) {
									par[1] = delh;
								}
								if(vars.length > 0) {
								for(var g = 0; g < vars.length; g++) {
									par[1] =  newl[i].substring(k,j + 1)
									if(newl[i].substring(k,j + 1) == vars[g][0]) {
						par[1] = "VAR:" + getVarval(newl[i].substring(k,j + 1), 1)
								}else{
								par[1] = getVarval(newl[i].substring(k,j + 1), 1)
								}
							}		
								}else{
								par[1] =  getVarval(newl[i].substring(k,j + 1), 1)
								}		
				}
											
		}
			}
						vars.push(par)
			//print(vars)
		}
		if (newl[i].substring(0, 3) == "var") { 
		var vg = 0;
				var par = []
				var k = 0;
				var d = 3;
				for(var j = 3; j < newl[i].length; j++) {
					if(newl[i].substring(j,j + 1) == "+" == false && newl[i].substring(j,j + 1) == "-" == false &&  newl[i].substring(j,j + 1) == "=" == false) {
					par[0] = newl[i].substring(d,j + 1)
					}else{
						d = j + 1;
						 j = newl[i].length;
					}
				}
			for(var j = 0; j < vars.length; j++) {
				if(vars[j][0] == par[0]) {
					vg = j
				}
			}
			//print(newl[i].substring(d, newl[i].length - 1))
			if(newl[i].substring(d - 1, d) == "=") {
				vars[vg][1] = calc(newl[i].substring(d, newl[i].length - 1))
			}
			if(newl[i].substring(d - 2, newl[i].length) == "++;") {
				vars[vg][1] += 1;
				
			}
			if(newl[i].substring(d - 2, newl[i].length) == "--;") {
				vars[vg][1] -= 1;
			}
			//print(newl[i].substring(d+1, newl[i].length - 1))
			if(newl[i].substring(d - 1, d + 1) == "+=") {
				vars[vg][1] += calc(newl[i].substring(d+1, newl[i].length - 1), 1);
			}
			if(newl[i].substring(d - 1, d + 1) == "-=") {
				vars[vg][1] -= calc(newl[i].substring(d+1, newl[i].length - 1), 1);
			}
			//print(vars)
		}
		if (newl[i].substring(0, 10) == "frameRate(") { 
		fps = int(newl[i].substring(10, newl[i].length - 1))
		}
		if (newl[i].substring(0, 12) == "deltaLoops(") { 
		if(newl[i].substring(12, newl[i].length - 1) == "true") {
			usD = 1;
		}
		if(newl[i].substring(12, newl[i].length - 1) == "false") {
			usD = 0;
		}
		}
		}
	}
}

function getVarval(name ,falltoint) {
	var out = "NOVAL";
	if(name == "deltaTime()") {
		out = delh
	}
				for(var k = 0; k < vars.length; k++) {
					if(str(name) == vars[k][0]) {
						//print("var", vars[k])
						out = vars[k][1]
						k = vars.length
					}
			}
	if(falltoint == 1 && out == "NOVAL") {
		if(name == "true") {
			out = true
		}else{
		if(name == "false") {
			out = false
		}else{
				out = float(name)	
		}
		}
	}
	//print(out)
	return out
}

function calc(str) {
	var out = 0;
	var ns = str.replaceAll(" ", "")
	var numb = [0]
	var act = []
	var d = 0;
	for(var i = 0; i < ns.length + 1; i++) {
		if(ns.substring(i - 1, i) == "+" || ns.substring(i - 1, i) == "-" || ns.substring(i - 1, i) == "*" || ns.substring(i - 1, i) == "/") {
			numb.push(0)
			act.push(ns.substring(i - 1, i))
			d = i
		}else{
			numb[numb.length - 1] = ns.substring(d, i)
		}
	}
	for(var i = 0; i < numb.length; i++) {
		numb[i] = getVarval(numb[i], 1)
		if(numb[i] == true) {
		numb = [true]
		}
		if(numb[i] == false) {
		numb = [false]
		}

	}
	if(numb[0] == true || numb[0] == false) {}else{
	for(var i = 0; i < act.length; i++) {
		if(act[i] == "+") {
			numb[0] += numb[1]
			numb.splice(1, 1)
		}
		if(act[i] == "-") {
			numb[0] -= numb[1]
			numb.splice(1, 1)
		}
		if(act[i] == "/") {
			numb[0] /= numb[1]
			numb.splice(1, 1)
		}
		if(act[i] == "*") {
			numb[0] *= numb[1]
			numb.splice(1, 1)
		}
	}
	}
	return numb[0]
}

function deIf(txt) {
	var out = 0;
	if(txt.substring(0, 3) == "if(") {
			var par = ["NONE", "NONE"]
			var d = 0;
			for(var k = 3; k < txt.length; k++) {
				//print(newl[i].substring(k - 1, k))
				if(txt.substring(k - 1, k) == "=") {
					d = k;
			 k = txt.length
					par[1] = "="
			}else{
					par[0] = txt.substring(3, k)
			}
			
		}
			if(par[1] == "=") {
				for(var k = d + 1; k < txt.length; k++) {
				if(txt.substring(k - 1, k) == ")") {
					d = k;
			 k = txt.length
					//par[1] = "="
			}else{
					par[2] = txt.substring(d + 1, k)
			}
			}
				par[0] = calc(par[0], 1)
				par[2] = getVarval(par[2], 1)
			}
			if(par[0] == par[2]) {
				par[3] = true
			}else{
			par[3] = false
			}
		out = par[3]
		//print(par)
		}
	return out
}