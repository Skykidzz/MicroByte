/*
Example Code:

MICRODE--
VAR y = 54;
VAR v = 15;
VAR d = 0;
VAR e = true;

//makes the loop move with delta time
deltaLoops(true)

loop() {
    var d = deltaTime();
    if(e == true) {
    var y += v * d;
    var v -= 0.5;
    }
    rect(20,y,20,20)
    frameRate(60)
}
loop(60) {
    frameRate(30)
}

*/

var lines = ["unc"]
var imd = 0;
var fps = 10000;
var newl = []
var delh = 0;

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	  input = createFileInput(handleFile);
	input.position(0,0)
}

function draw() {
	background(255)
	delh = deltaTime / 20;
	if(lines[0] == "unc" == false) {
	runScr()
		frameRate(fps)
	}
	//print(getFrameRate())
}

function handleFile(file) {
  print(file);
  if (file.type === 'text') {
    // If it's an image, create a p5.Image object
    imd = file.data;
	  if(imd.substring(0,9) == "MICRODE--") {
	  lines = imd.split("\n")
		  lines.splice(0, 1)
	  	for(var i = 0; i < lines.length; i++) {
		newl.push(lines[i].replaceAll(" ", ""))
	}
	  }else{
print('Not an MICRODE File!');
	  print("File Not Supported: " + file.type)
	  }
  } else {
    print('Not an MICRODE File!');
	  print("File Not Supported: " + file.type)
  }
}


